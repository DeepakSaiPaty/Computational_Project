# Measuring attitudes towards COVID-19 based on large scale social media analysis

Steps for Execution (Order Of Execution)::<br/>
1.Tweet Extraction<br/>
2.Merge files and country continent map <br/>
3.Language detection<br/>
4.Data Cleaning<br/>
(For cleaned data::https://drive.google.com/file/d/19kxwOAySsVLXxbg0ivWUvfBuFupGE6lt/view?usp=sharing)<br/>
5.Finding Tweets Sentiments using TextBlob<br/>
6.Tweets Date wise analysis<br/>
7.Topic Modelling<br/>
8.Tweets Sentiment Analysis using ML model<br/>
